package domein;

public class ContractRepository {
}
