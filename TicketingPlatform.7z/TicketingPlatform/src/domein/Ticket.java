package domein;

public class Ticket {

}
