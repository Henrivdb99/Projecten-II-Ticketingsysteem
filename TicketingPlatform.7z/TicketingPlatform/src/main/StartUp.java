package main;

import domein.GebruikerController;

public class StartUp {

	public static void main(String[] args) {
		System.out.println("Hello world");
		
		GebruikerController gc = new GebruikerController(true);

	}

}
